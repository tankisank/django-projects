from django.contrib import admin
from .models import foods

# Register your models here.

class foodsAdmin(admin.ModelAdmin):
    list_display = ('Name','Type','Vitamin')
    list_filter = ('Type',)
    ordering = ('Vitamin',)
    search_fields = ('Name',)

admin.site.register(foods,foodsAdmin)