from django.db import models

# Create your models here.

food_type = (("1","Vegetables"),("2","Fruits"),("3","Nuts"))

class foods(models.Model):
    Name = models.CharField(max_length=50)
    Type = models.CharField(max_length=50,choices=food_type)
    Vitamin = models.CharField(max_length=50)

    def __str__(self):
        return self.Type
